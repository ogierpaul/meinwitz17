from setuptools import setup

setup(name='meinwitz17',
      version ='0.1',
      description='die beste witz in der welt',
      author='Paul Ogier',
      author_email='ogier.paul@gmail.com',
      license='MIT',
      packages=['meinwitz17'],
      zip_safe=False)